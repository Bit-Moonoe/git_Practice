package dev.bank.bankstatement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dev.bank.bankstatement.entity.Address;
import dev.bank.bankstatement.entity.User;
import dev.bank.bankstatement.jwt.JwtTokenGenerator;
import dev.bank.bankstatement.repository.AddressRepository;
import dev.bank.bankstatement.service.UserService;

@RestController
@RequestMapping("users") // react 혹은 Postman 등에서 request 전송 시 http://localhost:8090/users로 요청 시 처리를 담당할 컨트롤러
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private JwtTokenGenerator jwtTokenGenerator;
	
	
	/** Java Doc 작성용 주석
	 *  해당 메서드에 대한 간단한 동작 서술 -> "모든 User list를 반환한다"
	 * 
	 *  @return List<User>
	 *  @author guguttemi
	 */
	@GetMapping // 'GET' http://localhost:8090/users 요청 시 호출되는 메서드(핸들러)
	public List<User.Response> getUsers() {
		System.out.println("GET: getUsers() of UserController called");
		List<User> users = userService.findAllUsers();
		List<User.Response> response = User.Response.toResponseList(users); 
		return response;
	}
	
	/**
	 * id에 해당하는 단일 User 정보를 User entity 타입으로 반환한다.
	 * 
	 * @param id - 조회하고자 하는 User의 id
	 * @return User - 조회된 User Entity 객체
	 */
	@GetMapping("/{id}") // 'GET' localhost:8090/users/guguttemi
	public User.Response getUser(@PathVariable String id) {		
		User foundUser = userService.findUserById(id); 
		return User.Response.toResponse(foundUser);
	}
	
	/**
	 * 새로운 User를 등록한다.
	 * 
	 * @param user - User Entity 
	 * @return user - DB에 등록된 User 객체  
	 * @author guguttemi
	 */
	@PostMapping // POST: http://localhost:8090/users
	public ResponseEntity<User.Response> createUser(@RequestBody @Valid User.Request request) {
		// Convert User Request(DTO) -> User Entity
		User user = User.Request.toEntity(request);
		Address address = request.getAddress();
		
		User savedUser = userService.saveUser(user);
		
		address.setUser(savedUser);
		addressRepository.save(address);
		
//		return User.Response.toResponse(savedUser); // ResponseDTO로 반환하는 방식
		User.Response response = User.Response.toResponse(savedUser); // ResponseEntity로 반환하는 방식 
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}
	
	@PostMapping("auth/sign-in")
	public ResponseEntity<User.Response> signIn(@RequestBody User.Request request) {
//		System.out.println(request);
		
		// 로그인된 user 확인
		User user = userService.loginUser(request);
		
		// 로그인된 유저에 대한 토큰 생성
		String token = jwtTokenGenerator.generateToken(user);
		
		// 클라이언트에 응답할 데이터로 변환
		User.Response responseData = User.Response.toResponse(user);
		
		responseData.setToken(token);
		
		return ResponseEntity.status(HttpStatus.OK).body(responseData);
	}
	
	@PutMapping
	public List<User.Response> updateUser(@RequestBody User.Request request) {
		List<User> users = userService.updateUser(request);
		return User.Response.toResponseList(users); // DTO로 변환 후 반환
	}
	
	@DeleteMapping
	public List<User.Response> deleteUser(@RequestParam("id") String id) {
		List<User> users = userService.deleteUser(id);
		return User.Response.toResponseList(users);
	}
}















