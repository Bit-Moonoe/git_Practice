package dev.bank.bankstatement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankstatementApplicationTests {

	@Test
	void contextLoads() {
	}

}
