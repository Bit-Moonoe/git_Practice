package dev.bank.bankstatement.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// jpa
@Entity
@Table(name = "USERS") // 테이블이 USERS라는 이름으로 생성되도록 설정, 'USER'는 일반적으로 DBMS 예약어로 사용되기 때문에
// lombok 
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter @Setter
public class User {
	
	@Id
	@Column(name = "USER_ID")
	private String id; // User ID

	@Column(nullable = false)
	private String password; // User password

	@Column(nullable = false)
	private String name;

	@Enumerated(EnumType.STRING)
	private Gender gender; // 별도의 Enum type Gender
	
	@OneToMany(mappedBy = "user")
	private List<Address> addresses;

	@Override
	public String toString() {
		return "User";
	}
	
	// 요청 받을 때 사용할 User Entity의 DTO 클래스
	@Setter 
	@Getter
	@Builder
	@ToString
	public static class Request {
		@NotBlank(message = "id는 공백('', ' ')이나 Null 지정 불가")
		private String id;
		@NotBlank(message = "password는 공백('', ' ')이나 Null 지정 불가")
		private String password;
		@NotBlank(message = "name은 공백('', ' ')이나 Null 지정 불가")
		private String name;
		
		private Gender gender;
		
		private Address address;
		
		public static User toEntity(final Request request) {
			// Lombok의 빌더 패턴 사용!! 
			return User.builder()
					.id(request.getId())
					.password(request.getPassword())
					.name(request.getName())
					.gender(request.getGender())
					.addresses(new ArrayList<>())
					.build(); // 빌드 진행시켜..
		}

	}

	// 서버가 응답할 때 사용할 User Entity의 DTO 클래스
	@Setter @Getter
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Response {
		private String id;
		private String name;
		private Gender gender;
		private List<Address.Response> addresses;
		private String token;
		
		public Response(User user) {
			this.id = user.getId();
			this.name = user.getName();
			this.gender = user.getGender();
			this.addresses = Address.Response.toAddressResponseList(user.getAddresses());
		}
		
		// User Entity를 Response(DTO)로 변환하는 메서드
		public static User.Response toResponse(final User user) {
			return Response.builder()
					.id(user.getId())
					.name(user.getName())
					.gender(user.getGender())
					.addresses(Address.Response.toAddressResponseList(user.getAddresses()))
					.build();
		}
		
		public static List<Response> toResponseList(final List<User> users) {
//			List<User.Response> list = new ArrayList<>();
//			for (User user : users) {
//				list.add(toResponse(user));
//			}
//			return list;
//			return users.stream().map(user -> new Response(user)).collect(Collectors.toList());
			return users.stream().map(Response::new).collect(Collectors.toList());
			// users: List<User>
			// users를 가지고 통로 하나 열어봐 처리좀 하게 -> stream()
			// users에 있는 user 하나 꺼내서 new Response()부분에 user를 집어넣어 -> 하나의 Response 객체 생성 완료! -> map(): forEach()가 돌고있는 것
			// -> 병렬 처리 -> 여러 개의 Response 객체가 생성된 것 (대기 중...)
			// 다 만들었어? 그럼 모아 -> collect()
			// Collector: 모으는 사람?
			// 모은거 가지고 List로 만들어
		}
	}

	

	
}
