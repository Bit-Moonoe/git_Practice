package dev.bank.bankstatement.entity;

public enum Gender {
	MALE, FEMALE, NOTYET
}
