package dev.bank.bankstatement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankstatementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankstatementApplication.class, args);
	}

}
