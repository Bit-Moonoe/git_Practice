package dev.bank.bankstatement.service;

import java.util.List;

import dev.bank.bankstatement.entity.User;

public interface UserService {
	List<User> findAllUsers();
	
	User findUserById(String id);
	
	User saveUser(User newUser);
	
	User loginUser(User.Request request);
	
	List<User> updateUser(User.Request request);
	
	List<User> deleteUser(String id);
}
